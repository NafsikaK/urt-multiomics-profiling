############################################################################################################
# GET.NUMBER.OF.ZEROS
############################################################################################################
get.number.of.positives <- function(x){
  if(any(x>0)){
    number.of.positives <- length(x[x>0])
    }else{
      number.of.positives <- 0
    }
  return(number.of.positives)
  }
#
############################################################################################################
# INTERSECTION
############################################################################################################
intersection <- function(a, b) {
  intersect <- vector()
  
  for(i in 1:length(a)) {
    if(a[i] %in% b) {
      intersect <- append(intersect, a[i])
    }
  }
  return(intersect)
  }
#
############################################################################################################
# CREATE.NAMES
############################################################################################################
create.names <- function(data.set){
  names.of.variables <- NULL
  for(j in (1:ncol(data.set))){
    names.of.variables.j <- paste(unlist(strsplit(x=names(data.set)[j],split="\\.")),collapse=" ")
    names.of.variables <- c(names.of.variables,paste(names.of.variables.j,sep=""))
    }
  return(names.of.variables)
  }
#
create.names <- function(names.to.create){
  names.of.variables <- NULL
  for(j in (1:length(names.to.create))){
    names.of.variables.j <- paste(unlist(strsplit(x=names.to.create[j],split="\\.")),collapse=" ")
    names.of.variables <- c(names.of.variables,paste(names.of.variables.j,sep=""))
    }
  return(names.of.variables)
  }
#
############################################################################################################
# SHOW.MISSING.BY.VARIABLE
############################################################################################################
show.missing.by.variable <- function(data.set,plot){
  missing.by.variable <- rep(0,ncol(data.set))
  names(missing.by.variable) <- names(data.set)
  for(j in (1:length(missing.by.variable))){
    missing.by.variable[j] <- sum(is.na(data.set[,j]))
    }
  missing.by.variable <- 	missing.by.variable/nrow(data.set)
  if(plot){
    par(mar=c(5,12,1,2))
    barplot(missing.by.variable,horiz=TRUE,las=1,xlab="Proportion of missing observations",
            col="lavender",cex.axis=1.25,cex.lab=1.25)
    }
  return(missing.by.variable)
  }
#
############################################################################################################
# CREATE.STRATIFICATION
############################################################################################################
create.stratification <- function(names.of.confounders,confounders){
  aux.confounders <- subset(confounders,select=names.of.confounders)
  aux.confounders <- transform(aux.confounders,
                               stratum=rep(NA,nrow(aux.confounders)))
  for(i in (1:nrow(aux.confounders))){
    aux.confounders[i,]$stratum <- paste(aux.confounders[i,1:length(names.of.confounders)],collapse="/")
    }
  aux.confounders$stratum <- as.factor(as.character(aux.confounders$stratum))
  confounders <- transform(confounders,stratum=aux.confounders$stratum)
  return(confounders)
  }
#
############################################################################################################
# CHECK.STRATA
############################################################################################################
check.strata <- function(s,data.to.test){
	aux.data.to.test <- subset(data.to.test,stratum==s)
	check <- min(length(unique(aux.data.to.test[,1])),length(unique(aux.data.to.test[,2])))
	return(check)
	}
#
############################################################################################################
# TEST.one.ASSOCIATION
# NB: Tests based on the whole data set blocked by stratum 
############################################################################################################
test.ONE.association <- function(data.for.testing,TYPES,B){
  #	data.for.testing <- data.for.testing.b
  #	TYPES <- TYPES.b; B <- 100000; Spearman.rather.than.AD <- TRUE
  Spearman.rather.than.inner.product <- FALSE
  p.value <- test <- sample.characteristics <- Sign <- NA
  
  response.by.treatment <- data.for.testing
  response.by.treatment$stratum <- as.character(response.by.treatment$stratum)
  names(response.by.treatment)[1:2] <- c("response","treatment")
  
  checks.by.stratum <- t(sapply(response.by.treatment$stratum,check.strata,response.by.treatment))
  good.strata <- response.by.treatment$stratum[checks.by.stratum>1]

  tested <- FALSE
  
  if(length(good.strata)>1){
    
    response.by.treatment <- subset(response.by.treatment,is.element(stratum,good.strata))
    rownames(response.by.treatment) <- NULL
    response.by.treatment$stratum <- as.factor(response.by.treatment$stratum)
    
    type.1 <- TYPES[1]; type.2 <- TYPES[2]
    if((type.1=="binary" & type.2!="binary") | 
       (type.1=="categorical" & (type.2!="categorical" & type.2!="binary")) | 
       (type.1=="ordinal" & (type.2!="ordinal" & type.2!="categorical" & type.2!="binary"))){
      response.by.treatment <- response.by.treatment[,c(2,1,3)]
      type.2 <- TYPES[1]
      type.1 <- TYPES[2]
    }
    
    if((is.element(type.2,c("dirac.and.continuous","ordinal")) &
        is.element(type.1,c("dirac.and.continuous","ordinal"))) |
       (is.element(type.2,c("continuous","ordinal")) &
        is.element(type.1,c("dirac.and.continuous","ordinal"))) |
       (is.element(type.1,c("continuous","ordinal")) &
        is.element(type.2,c("dirac.and.continuous","ordinal"))) |
       ((Spearman.rather.than.inner.product==FALSE) & is.element(type.2,c("continuous")) & is.element(type.1,c("continuous"))) |
       (is.element(type.2,c("binary")) &
        is.element(type.1,c("dirac.and.continuous","continuous","ordinal")))){
     
      independence.test <- independence_test(response~treatment|stratum,data=response.by.treatment,
                                             distribution=approximate(nresample=B),teststat="scalar") 
      p.value <- as.numeric(pvalue(independence.test))
      Sign <- sign(statistic(spearman_test(response~treatment|stratum,data=response.by.treatment,
                                           distribution="asymptotic")))
      list.of.samples <- split(response.by.treatment$response,f=response.by.treatment$treatment)
      test <- "Inner product statistic"
      k <- length(list.of.samples)
      if(length(names(list.of.samples))<=5){
        sample.characteristics <- NULL
        for(j in (1:k)){
          sample.characteristics <- c(sample.characteristics,length(list.of.samples[[j]]))
        }
        sample.characteristics <- paste(sample.characteristics,collapse="/")
      }else{
        sample.characteristics <- "too many"         
      }
      tested <- TRUE
      
    }
    
    if((type.1=="continuous" & type.2=="continuous") & (Spearman.rather.than.inner.product)){
      
      Spearman.test <- spearman_test(response~treatment|stratum,data=response.by.treatment,
                                     distribution=approximate(nresample=B)) 
      p.value <- as.numeric(pvalue(Spearman.test))
      Sign <- sign(statistic(Spearman.test))
      test <- "Spearman"
      sample.characteristics <- NA         
      tested <- TRUE
      
    }
    
    if(is.element(type.2,c("binary","categorical")) &
       is.element(type.1,c("dirac.and.continuous","continuous")) & (tested==FALSE)){
      
      KW.test <- kruskal_test(response~as.factor(treatment)|stratum,data=response.by.treatment,
                              distribution=approximate(nresample=B))
      p.value <- as.numeric(pvalue(KW.test))
      if(type.2=="binary"){
        Sign <- sign(cor(y=response.by.treatment$response,
                         x=response.by.treatment$treatment))
      }else{
        Sign <- 0
      }
      list.of.samples <- split(response.by.treatment$response,f=response.by.treatment$treatment)
      test <- "Kruskal-Wallis"
      k <- length(list.of.samples)
      sample.characteristics <- NULL
      for(j in (1:k)){
        sample.characteristics <- c(sample.characteristics,length(list.of.samples[[j]]))
      }
      sample.characteristics <- paste(sample.characteristics,collapse="/")
      tested <- TRUE
      
    }
    
    if(is.element(type.1,c("binary","categorical","ordinal")) &
       is.element(type.2,c("binary","categorical","ordinal")) & (tested==FALSE)){
      
      CHM.test <- cmh_test(as.factor(response)~as.factor(treatment)|stratum,
                           data=response.by.treatment,distribution=approximate(nresample=B))
      p.value <- as.numeric(pvalue(CHM.test))
      if((type.1=="binary" & type.2!="categorical") | (type.2=="binary" & type.1!="categorical")){
        Sign <- sign(cor(y=response.by.treatment$response,
                         x=response.by.treatment$treatment))
      }else{
        Sign <- 0
      }
      test <- "Cochran-Mantel-Haenszel"
      list.of.samples <- split(response.by.treatment$response,f=response.by.treatment$treatment)
      k <- length(list.of.samples)
      sample.characteristics <- NULL
      for(j in (1:k)){
        sample.characteristics <- c(sample.characteristics,length(list.of.samples[[j]]))
      }
      sample.characteristics <- paste(sample.characteristics,collapse="/")
      tested <- TRUE
      
    }
    
  }
  
  if(tested==FALSE){
    print(paste("Did not test ",paste(names(data.for.testing)[1:2],collapse=", "),"!",sep=""))
  }
  
  return(c(names(data.for.testing)[1:2],as.character(p.value),Sign,test,
           sample.characteristics))
}
#
############################################################################################################
# ILLUSTRATE.one.ASSOCIATION
############################################################################################################
illustrate.ONE.association <- function(data.for.plotting,types,log.scale,main.title){
  #	data.for.plotting <- data.for.plotting.r; types <- TYPES.r
  #	data.for.plotting <- data.for.plotting.r.s; types <- TYPES.r
  
  plotted <- FALSE
  colour.palette <- c("lavender","lightblue","cornflowerblue","aquamarine2",
                      "lightgreen","olivedrab2","palegreen1","dodgerblue","cyan",
                      "bisque2","burlywood2","darkgoldenrod3",
                      "bisque4","black","blueviolet","darkorchid4","blue",
                      "cyan2","aquamarine4","chartreuse3","darkolivegreen2","darkseagreen3","grey",
                      "darkkhaki","darkorange4","brown3","red","darksalmon","orange1","yellow","yellow3",
                      "springgreen2","lavender","sienna2","pink3","khaki1",
                      "darkmagenta","azure2")
  
  data.to.plot <- data.for.plotting[,c(1,2)]
  type.1 <- types[1]; type.2 <- types[2]
  if((type.2=="binary" & type.1!="binary") | (type.2=="categorical" & type.1!="binary")){
    data.to.plot <- data.to.plot[,c(2,1)]
    type.2 <- types[1]
    type.1 <- types[2]
  }
  good.names <- create.names(names(data.to.plot))
  names(data.to.plot) <- c("x","y")
  
  if(type.1=="dirac.and.continuous"){
    if(sum(data.to.plot$x==0)<=1){type.1 <- "continuous"}
  }
  if(type.2=="dirac.and.continuous"){
    if(sum(data.to.plot$y==0)<=1){type.2 <- "continuous"}
  }
  
  if(is.element(type.1,c("categorical","binary")) & type.2=="dirac.and.continuous"){
    data.to.plot$x <- as.character(data.to.plot$x)
    par(mfrow=c(1,2),mgp=c(2.5,1,0))
    aux.table <- table(data.to.plot[,2])
    atom <- as.numeric(dimnames(aux.table)[[1]][which.max(as.vector(aux.table))])
    aux.data.to.plot <- transform(data.to.plot,
                                  y=ifelse(y>atom,paste(">",atom,sep=""),
                                           ifelse(y<atom,paste("<",atom,sep=""),paste("=",atom,sep=""))))
    contingency.table <- table(aux.data.to.plot) 
    frequency.table <- contingency.table/rowSums(contingency.table)	
    barplot(t(frequency.table),beside=TRUE,col=colour.palette[1:ncol(frequency.table)],
            ylab="Proportion",ylim=c(0,1.5*max(frequency.table)),
            xlab=good.names[1])
    legend(x="top",legend=colnames(frequency.table),horiz=TRUE,cex=1.1,bty="n",
           fill=colour.palette[1:nrow(frequency.table)],title=good.names[2])
    aux.data.to.plot <- subset(data.to.plot,y!=atom)
    if(nrow(aux.data.to.plot)>0){
      if(length(unique(aux.data.to.plot$x))==1){
        x.label <- paste(good.names[1],"=",unique(aux.data.to.plot$x),collapse="")
      }else{
        x.label <- good.names[1] 
      }
      if(log.scale & all(aux.data.to.plot$y>0)){
        boxplot(log(y)~x,data=aux.data.to.plot,col="lavender",xlab=x.label,
                ylab=paste("log(",good.names[2],")",collapse=""))
        stripchart(log(y)~x,data=aux.data.to.plot,col="red",add=TRUE,vertical=TRUE,cex=0.5)
      }else{
        boxplot(y~x,data=aux.data.to.plot,col="lavender",xlab=x.label,
                ylab=good.names[2])
        stripchart(y~x,data=aux.data.to.plot,col="red",add=TRUE,vertical=TRUE,cex=0.5)
      }
      plotted <- TRUE
    }
  }
  
  if(is.element(type.1,c("categorical","binary")) & is.element(type.2,c("categorical","binary"))){
    data.to.plot$x <- as.character(data.to.plot$x)
    data.to.plot$y <- as.character(aux.data.to.plot$y)
    par(mfrow=c(1,1),mgp=c(2.5,1,0))
    contingency.table <- table(data.to.plot) 
    frequency.table <- contingency.table/rowSums(contingency.table)		
    barplot(t(frequency.table),beside=TRUE,col=colour.palette[1:ncol(frequency.table)],
            ylab="Proportion",ylim=c(0,1.5*max(frequency.table)),
            xlab=good.names[1])
    legend(x="top",legend=dimnames(frequency.table)$y,horiz=TRUE,cex=1.1,bty="n",
           fill=colour.palette[1:ncol(frequency.table)],title=good.names[2])
    plotted <- TRUE
  }
  
  if(is.element(type.2,c("categorical","binary","ordinal")) & type.1=="continuous"){
    type.1 <- type.2
    type.2 <- "continuous"
    data.to.plot <- data.to.plot[,c(2,1)]
    good.names <- good.names[2:1]
    names(data.to.plot ) <- c("x","y")
  }
  
  if(is.element(type.1,c("categorical","binary","ordinal")) & type.2=="continuous"){
    data.to.plot$x <- as.character(data.to.plot$x)
    par(mfrow=c(1,1),mgp=c(2.5,1,0))
    if(log.scale & all(data.to.plot$y>0)){
      if(length(unique(data.to.plot$x))<=4){
        boxplot(log(y)~x,data=data.to.plot,col="lavender",xlab=good.names[1],
                ylab=paste("log(",good.names[2],")",collapse=""))
        stripchart(log(y)~x,data=data.to.plot,col="red",add=TRUE,vertical=TRUE,cex=0.5)
      }else{
        plot(log(y)~x,data=data.to.plot,col="blue",xlab=good.names[1],
             ylab=paste("log(",good.names[2],")",collapse=""))       
      }
    }else{
      if(length(unique(data.to.plot$x))<=4){
        boxplot(y~x,data=data.to.plot,col="lavender",xlab=good.names[1],
                ylab=good.names[2])
      }else{
        plot(y~x,data=data.to.plot,col="blue",xlab=good.names[1],
             ylab=good.names[2])
      }
    }
    plotted <- TRUE
  }
  
  if((type.1=="ordinal" & type.2=="ordinal") | 
     (type.1=="binary" & type.2=="ordinal") | (type.1=="categorical" & type.2=="ordinal")){
    if((type.1=="categorical") | (type.1=="binary")){data.to.plot$x <- as.character(data.to.plot$x)}
    aux.table.1 <- table(data.to.plot[,1]); aux.table.2 <- table(data.to.plot[,2])
    par(mfrow=c(1,1),mgp=c(2.5,1,0))
    if(length(aux.table.2)>length(aux.table.1)){	
      aux.means <- aggregate(y~x,data=data.to.plot,mean)
      boxplot(y~x,data=data.to.plot,col="lavender",xlab=good.names[1],ylab=good.names[2])
      points(y~as.factor(x),data=aux.means,col="red",xlab=good.names[1],ylab=good.names[2],
             cex=1.25,pch=19)
    }else{
      aux.means <- aggregate(x~y,data=data.to.plot,mean)
      boxplot(x~y,data=data.to.plot,col="lavender",xlab=good.names[2],ylab=good.names[1])
      points(x~as.factor(y),data=aux.means,col="red",pch=19,cex=1.25,
             xlab=good.names[2],ylab=good.names[1])
    } 
    plotted <- TRUE
  }
  
  if(type.1=="continuous" & type.2=="continuous"){
    par(mfrow=c(1,1),mgp=c(2.5,1,0))
    plot(y~x,data=data.to.plot,col="blue",xlab=good.names[1],ylab=good.names[2])
    plotted <- TRUE
  }
  
  if(type.1=="dirac.and.continuous" & type.2=="ordinal"){
    type.1 <- "ordinal"
    type.2 <- "dirac.and.continuous"
    data.to.plot <- data.to.plot[,c(2,1)]
    good.names <- good.names[2:1]
    names(data.to.plot ) <- c("x","y")
  }
  
  if(type.1=="ordinal" & type.2=="dirac.and.continuous"){
    aux.table <- table(data.to.plot[,2])
    atom <- as.numeric(dimnames(aux.table)[[1]][which.max(as.vector(aux.table))])
    if(atom==0){
      par(mfrow=c(1,2),mgp=c(2.5,1,0))
      aux.data.to.plot <- transform(data.to.plot,
                                    y=ifelse(y>atom,paste(">",atom,sep=""),
                                             ifelse(y<atom,paste("<",atom,sep=""),paste("=",atom,sep=""))))
      if(length(unique(aux.data.to.plot$x))<=4 & length(unique(aux.data.to.plot$y))>1){
        contingency.table <- t(table(aux.data.to.plot))
        frequency.table <- contingency.table/rowSums(contingency.table)
        barplot(t(frequency.table),beside=TRUE,col=colour.palette[1:ncol(frequency.table)],
                ylab="Proportion",ylim=c(0,1.5*max(frequency.table)),xlab=good.names[2])
        legend(x="top",legend=colnames(frequency.table),horiz=TRUE,cex=1.1,bty="n",
               fill=colour.palette[1:ncol(frequency.table)],title=good.names[1])
      }else{
        boxplot(x~y,data=aux.data.to.plot,col="lavender",xlab=good.names[2],ylab=good.names[1])
        stripchart(x~y,data=aux.data.to.plot,col="red",add=TRUE,vertical=TRUE,cex=0.5)  
      }
    }else{
      if(length(unique(data.to.plot$y))>1){par(mfrow=c(1,1),mgp=c(2.5,1,0))}
    }
    aux.data.to.plot <- subset(data.to.plot,y!=0)
    if(nrow(aux.data.to.plot)>1){
      if(length(unique(aux.data.to.plot$x))<=4){
        if(log.scale & all(aux.data.to.plot$y>0)){
          boxplot(log(y)~x,data=aux.data.to.plot,col="lavender",xlab=good.names[1],
                  ylab=paste("log(",good.names[2],")",collapse=""))
          stripchart(log(y)~x,data=aux.data.to.plot,col="red",add=TRUE,vertical=TRUE,cex=0.5)
        }else{
          boxplot(y~x,data=aux.data.to.plot,col="lavender",xlab=good.names[1],
                  ylab=good.names[2])
          stripchart(x~y,data=aux.data.to.plot,col="red",add=TRUE,vertical=TRUE,cex=0.5)
        }
      }else{
        plot(y~x,data=aux.data.to.plot,col="blue",pch=1,cex=0.8,xlab=good.names[1],ylab=good.names[2])
      }
    }
    plotted <- TRUE
  }
  
  if(type.1=="dirac.and.continuous" & type.2=="dirac.and.continuous"){
    aux.table.1 <- table(data.to.plot[,1])
    aux.table.2 <- table(data.to.plot[,2])
    atom.1 <- as.numeric(dimnames(aux.table.1)[[1]][which.max(as.vector(aux.table.1))])
    atom.2 <- as.numeric(dimnames(aux.table.2)[[1]][which.max(as.vector(aux.table.2))])
    aux.data.to.plot <- transform(data.to.plot,
                                  x=ifelse(x>atom.1,paste(">",atom.1,sep=""),
                                           ifelse(x<atom.1,paste("<",atom.1,sep=""),paste("=",atom.1,sep=""))),
                                  y=ifelse(y>atom.2,paste(">",atom.2,sep=""),
                                           ifelse(y<atom.2,paste("<",atom.2,sep=""),paste("=",atom.2,sep=""))))
    contingency.table <- table(aux.data.to.plot)
    frequency.table <- contingency.table/rowSums(contingency.table)
    aux.data.to.plot <- subset(data.to.plot,x!=atom.1 & y!=atom.2)
    if(nrow(aux.data.to.plot)>=1){
      par(mfrow=c(1,2),mgp=c(2.5,1,0))
    }
    barplot(t(frequency.table),beside=TRUE,col=colour.palette[1:ncol(frequency.table)],
            ylab="Proportion",ylim=c(0,1.5*max(frequency.table)),
            xlab=good.names[1])
    legend(x="top",legend=colnames(frequency.table),horiz=TRUE,cex=1.1,bty="n",
           fill=colour.palette[1:ncol(frequency.table)],title=good.names[2])
    if(nrow(aux.data.to.plot)>=1){
      plot(y~x,data=aux.data.to.plot,col="blue",xlab=good.names[1],ylab=good.names[2])
      stripchart(y~x,data=aux.data.to.plot,col="red",add=TRUE,vertical=TRUE,cex=0.5)
    }
    plotted <- TRUE
  }
  
  if(type.2=="dirac.and.continuous" & type.1=="continuous"){
    type.1 <- "dirac.and.continuous"
    type.2 <- "continuous"
    data.to.plot <- data.to.plot[,c(2,1)]
    good.names <- good.names[2:1]
    names(data.to.plot ) <- c("x","y")
  }
  
  if(type.1=="dirac.and.continuous" & type.2=="continuous"){
    par(mfrow=c(1,2),mgp=c(2.5,1,0))
    aux.table <- table(data.to.plot[,1])
    atom <- as.numeric(dimnames(aux.table)[[1]][which.max(as.vector(aux.table))])
    aux.data.to.plot <- transform(data.to.plot,
                                  x=ifelse(x>atom,paste(">",atom,sep=""),
                                           ifelse(x<atom,paste("<",atom,sep=""),paste("=",atom,sep=""))))
    if(log.scale & all(aux.data.to.plot$y>0)){
      boxplot(log(y)~x,data=aux.data.to.plot,col="lavender",xlab=good.names[1],
              ylab=paste("log(",good.names[2],")",collapse=""))
      stripchart(log(y)~x,data=aux.data.to.plot,col="red",add=TRUE,vertical=TRUE,cex=0.5)
    }else{
      boxplot(y~x,data=aux.data.to.plot,col="lavender",xlab=good.names[1],
              ylab=good.names[2])
      stripchart(y~x,data=aux.data.to.plot,col="red",add=TRUE,vertical=TRUE,cex=0.5)
      aux.data.to.plot <- subset(data.to.plot,x!=atom)
      plot(y~x,data=aux.data.to.plot,col="blue",xlab=good.names[1],ylab=good.names[2])
    }
    plotted <- TRUE
  }
  
  if(((type.1=="binary" & type.2=="ordinal") | (type.1=="categorical" & type.2=="ordinal")) &
     (plotted==FALSE)){
    if((type.1=="categorical") | (type.1=="binary")){data.to.plot$x <- as.character(data.to.plot$x)}
    par(mfrow=c(1,1),mgp=c(2.5,1,0))
    contingency.table <- table(data.to.plot) 
    frequency.table <- contingency.table/rowSums(contingency.table)		
    barplot(t(frequency.table),beside=TRUE,col=colour.palette[1:ncol(frequency.table)],
            ylab="Proportion",ylim=c(0,1.5*max(frequency.table)),
            xlab=good.names[1])
    legend(x="top",legend=dimnames(frequency.table)$y,horiz=TRUE,cex=1.1,bty="n",
           fill=colour.palette[1:ncol(frequency.table)],title=good.names[2])
    plotted <- TRUE
  }
  
  if(plotted==FALSE){
    print(paste("Did not plot ",paste(names(data.for.plotting)[1:2],collapse=","),"!",sep=""))
  }else{
    if(is.null(main.title)==FALSE){
      title(main=main.title,outer=TRUE)
    }
  }
  
}
#
############################################################################################################
# TEST.one.ASSOCIATION.0
# NB: Tests based on the whole data set blocked by stratum 
#     This version uses the asymptotic distribution
############################################################################################################
test.ONE.association.0 <- function(data.for.testing,TYPES){
  #	data.for.testing <- data.for.testing.i
  #	TYPES <- TYPES.i; B <- 100000; Spearman.rather.than.AD <- TRUE
  Spearman.rather.than.inner.product <- FALSE
  p.value <- test <- sample.characteristics <- Sign <- NA
  
  response.by.treatment <- data.for.testing
  response.by.treatment$stratum <- as.character(response.by.treatment$stratum)
  names(response.by.treatment)[1:2] <- c("response","treatment")
  
  checks.by.stratum <- t(sapply(response.by.treatment$stratum,check.strata,response.by.treatment))
  good.strata <- response.by.treatment$stratum[checks.by.stratum>1]
  
  tested <- FALSE
  
  if(length(good.strata)>1){
    
    response.by.treatment <- subset(response.by.treatment,is.element(stratum,good.strata))
    rownames(response.by.treatment) <- NULL
    response.by.treatment$stratum <- as.factor(response.by.treatment$stratum)
    
    type.1 <- TYPES[1]; type.2 <- TYPES[2]
    if((type.1=="binary" & type.2!="binary") | 
       (type.1=="categorical" & (type.2!="categorical" & type.2!="binary")) | 
       (type.1=="ordinal" & (type.2!="ordinal" & type.2!="categorical" & type.2!="binary"))){
        response.by.treatment <- response.by.treatment[,c(2,1,3)]
        type.2 <- TYPES[1]
        type.1 <- TYPES[2]
      }

    if((is.element(type.2,c("dirac.and.continuous","ordinal")) &
        is.element(type.1,c("dirac.and.continuous","ordinal"))) |
       (is.element(type.2,c("continuous","ordinal")) &
        is.element(type.1,c("dirac.and.continuous","ordinal"))) |
       (is.element(type.1,c("continuous","ordinal")) &
        is.element(type.2,c("dirac.and.continuous","ordinal"))) |
       ((Spearman.rather.than.inner.product==FALSE) & is.element(type.2,c("continuous")) & is.element(type.1,c("continuous"))) |
       (is.element(type.2,c("binary")) &
        is.element(type.1,c("dirac.and.continuous","continuous","ordinal")))){
      
      independence.test <- independence_test(response~treatment|stratum,data=response.by.treatment,
                                             distribution="asymptotic",teststat="scalar") 
      p.value <- as.numeric(pvalue(independence.test))
      Sign <- sign(statistic(spearman_test(response~treatment|stratum,data=response.by.treatment,
                                           distribution="asymptotic")))
      list.of.samples <- split(response.by.treatment$response,f=response.by.treatment$treatment)
      test <- "Inner product statistic"
      k <- length(list.of.samples)
      if(length(names(list.of.samples))<=5){
        sample.characteristics <- NULL
        for(j in (1:k)){
          sample.characteristics <- c(sample.characteristics,length(list.of.samples[[j]]))
        }
        sample.characteristics <- paste(sample.characteristics,collapse="/")
      }else{
        sample.characteristics <- "too many"         
      }
      tested <- TRUE
      
    }
    
    if(type.1=="continuous" & type.2=="continuous" & Spearman.rather.than.inner.product){
      
      Spearman.test <- spearman_test(response~treatment|stratum,data=response.by.treatment,
                                     distribution="asymptotic") 
      p.value <- as.numeric(pvalue(Spearman.test))
      Sign <- sign(statistic(Spearman.test))
      test <- "Spearman"
      sample.characteristics <- NA         
      tested <- TRUE
      
    }
    
    if(is.element(type.2,c("binary","categorical")) &
       is.element(type.1,c("dirac.and.continuous","continuous")) & (tested==FALSE)){
      
      KW.test <- kruskal_test(response~as.factor(treatment)|stratum,data=response.by.treatment,
                              distribution="asymptotic")
      p.value <- as.numeric(pvalue(KW.test))
      if(type.2=="binary"){
        Sign <- sign(cor(y=response.by.treatment$response,
                         x=response.by.treatment$treatment))
      }else{
        Sign <- 0
      }
      list.of.samples <- split(response.by.treatment$response,f=response.by.treatment$treatment)
      test <- "Kruskal-Wallis"
      k <- length(list.of.samples)
      sample.characteristics <- NULL
      for(j in (1:k)){
        sample.characteristics <- c(sample.characteristics,length(list.of.samples[[j]]))
      }
      sample.characteristics <- paste(sample.characteristics,collapse="/")
      tested <- TRUE
      
    }
    
    if(is.element(type.1,c("binary","categorical","ordinal")) &
       is.element(type.2,c("binary","categorical","ordinal")) & (tested==FALSE)){
      
      CHM.test <- cmh_test(as.factor(response)~as.factor(treatment)|stratum,
                           data=response.by.treatment,distribution="asymptotic")
      p.value <- as.numeric(pvalue(CHM.test))
      if((type.1=="binary" & type.2!="categorical") | (type.2=="binary" & type.1!="categorical")){
        Sign <- sign(cor(y=response.by.treatment$response,
                         x=response.by.treatment$treatment))
      }else{
        Sign <- 0
      }
      test <- "Cochran-Mantel-Haenszel"
      list.of.samples <- split(response.by.treatment$response,f=response.by.treatment$treatment)
      k <- length(list.of.samples)
      sample.characteristics <- NULL
      for(j in (1:k)){
        sample.characteristics <- c(sample.characteristics,length(list.of.samples[[j]]))
      }
      sample.characteristics <- paste(sample.characteristics,collapse="/")
      tested <- TRUE
      
    }
    
  }
  
  if(tested==FALSE){
    print(paste("Did not test ",paste(names(data.for.testing)[1:2],collapse=", "),"!",sep=""))
  }
  
  return(c(names(data.for.testing)[1:2],as.character(p.value),Sign,test,
           sample.characteristics))
}
#
############################################################################################################
# Wilson.interval
############################################################################################################
Wilson.interval <- function(frequency,n,confidence){
  kappa <- qnorm(1-(1-confidence)/2)
  estimate <- frequency/n
  aux1 <- (frequency+(kappa^2)/2+kappa*sqrt(n)*
             sqrt(estimate*(1-estimate)+(kappa^2)/(4*n)))/(n+(kappa^2))
  aux2 <- (frequency+(kappa^2)/2-kappa*sqrt(n)*sqrt(estimate*(1-estimate)+(kappa^2)/(4*n)))/
    (n+(kappa^2))
  return(c(max(0.0,aux2),min(1.0,aux1)))
}
#
############################################################################################################
# statistics.over.strata
############################################################################################################
Spearman.per.stratum <- function(s,variables.by.stratum){
  return(cor(x=subset(variables.by.stratum,stratum==s)[,1],
             y=subset(variables.by.stratum,stratum==s)[,2],method="spearman"))
	}
correlation.per.stratum <- function(s,variables.by.stratum){
  return(cor(x=subset(variables.by.stratum,stratum==s)[,1],
             y=subset(variables.by.stratum,stratum==s)[,2]))
	}
odds.ratio.per.stratum <- function(s,variables.by.stratum){
  Fisher.test <- fisher.test(table(subset(variables.by.stratum,stratum==s)[,-3]))
  return(as.numeric(Fisher.test$estimate))
	}
Cramer.V.per.stratum <- function(s,variables.by.stratum){
  aux.variables.by.stratum <- subset(variables.by.stratum,stratum==s)[,-3]
  table(aux.variables.by.stratum)
  if(is.factor(aux.variables.by.stratum$x)){
     aux.variables.by.stratum$x <- as.character(aux.variables.by.stratum$x)}
  if(is.factor(aux.variables.by.stratum$y)){
    aux.variables.by.stratum$y <- as.character(aux.variables.by.stratum$y)}
	aux.table <- table(aux.variables.by.stratum)
	if(min(dim(aux.table))>1){
    Chi.square.test <- chisq.test(aux.table)
    Cramer.V <- as.numeric(Chi.square.test$statistic)/(sum(aux.table)*min(dim(aux.table)-1))
	  }else{
	  Cramer.V <- NA
	  }
  return(Cramer.V)
	}
difference.in.means.per.stratum <- function(s,variables.by.stratum){
	mean.of.y.by.x <- aggregate(y~x,data=subset(variables.by.stratum,stratum==s)[,-3],mean)
	difference.between.means <- (mean.of.y.by.x$y[2]-mean.of.y.by.x$y[1])
  return(difference.between.means)
	}
ratio.of.means.per.stratum <- function(s,variables.by.stratum){
  mean.of.y.by.x <- aggregate(y~x,data=subset(variables.by.stratum,stratum==s)[,-3],mean)
  ratio.of.means <- (mean.of.y.by.x$y[2]/mean.of.y.by.x$y[1])
  return(ratio.of.means)
  }
mean.absolute.difference.in.proportions.per.stratum <- function(s,variables.by.stratum){
	contingency.table <- table(subset(variables.by.stratum,stratum==s)[,-3])
	row.sums <- pmax(rowSums(contingency.table),1)
	relative.frequencies <- contingency.table/row.sums
  differences.between.proportions <- abs(relative.frequencies[,1]-relative.frequencies[,2])
  return(mean(differences.between.proportions))
	}
mean.absolute.deviation.from.overall.mean <- function(s,variables.by.stratum){
	mean.of.y.by.x <- aggregate(y~x,data=subset(variables.by.stratum,stratum==s)[,-3],mean)
	overall.mean <- mean(subset(variables.by.stratum,stratum==s)$y)
	mean.absolute.deviation <- mean(abs(mean.of.y.by.x$y-overall.mean))
  return(mean.absolute.deviation)
	}
#
statistics.over.strata <- function(data.for.calculating,TYPES,odds.ratio.instead.of.Cramer.V,
                                   sample.correlation.coefficient.instead.of.Spearman,
                                   ratio.of.means.instead.of.difference.in.means,
                                   median.of.ratios.instead.of.mean.of.ratios,
                                   mean.absolute.difference.in.proportions.instead.of.Cramer.V){
  #	data.for.calculating <- data.for.testing.i; TYPES <- TYPES.i
  
  variables.by.stratum <- data.for.calculating
  variables.by.stratum$stratum <- as.character(variables.by.stratum$stratum)
  names(variables.by.stratum)[1:2] <- c("y","x")
  
  checks.by.stratum <- t(sapply(variables.by.stratum$stratum,check.strata,variables.by.stratum))
  good.strata <- variables.by.stratum$stratum[checks.by.stratum>1]
  
  statistic <- NULL
  value.of.statistic <- NA
  
  if(length(good.strata)>1){
    
    variables.by.stratum <- subset(variables.by.stratum,is.element(stratum,good.strata))
    rownames(variables.by.stratum) <- NULL
    variables.by.stratum$stratum <- as.factor(variables.by.stratum$stratum)

    type.1 <- TYPES[1]; type.2 <- TYPES[2]

    if(length(unique(variables.by.stratum[,1]))==2){type.1 <- "binary"}
    if(length(unique(variables.by.stratum[,2])==2)){type.2 <- "binary"}
    if((type.1=="categorical") & (length(unique(variables.by.stratum[,1]))==2)){type.1 <- "binary"}
    if((type.2=="categorical") & (length(unique(variables.by.stratum[,2]))==2)){type.2 <- "binary"}

    if((type.1=="binary") & (type.2=="binary")){
       if(odds.ratio.instead.of.Cramer.V){
         statistic <- "odds.ratio"}else{statistic <- "Cramer.V"
         }
	    }

    if((type.2=="binary") & (type.1=="categorical")){
	    if(mean.absolute.difference.in.proportions.instead.of.Cramer.V){
	      statistic <- "mean.absolute.difference.in.proportions"
	      }else{
	      statistic <- "Cramer.V"
	      }
	    }

    if((type.1=="binary") & (type.2=="categorical" & is.null(statistic))){
       variables.by.stratum[,1:2] <- variables.by.stratum[,2:1]
       type.2 <- "binary"; type.1 <- "categorical"
       statistic <- "mean.absolute.difference.in.proportions"
       }

    if((type.1=="categorical") & (type.2=="categorical") & is.null(statistic)){
	    statistic <- "Cramer.V"
	    }

    if(is.element(type.1,c("numerical","dirac.and.continuous","ordinal")) & 
       (type.2=="binary") & is.null(statistic)){
      if(ratio.of.means.instead.of.difference.in.means){
        statistic <- "ratio.of.means"
        }else{
	      statistic <- "difference.in.means"
        }
	    }

    if(is.element(type.2,c("numerical","dirac.and.continuous","ordinal")) & 
       (type.1=="binary") & is.null(statistic)){
       variables.by.stratum[,1:2] <- variables.by.stratum[,2:1]
       type.1 <- type.2; type.2 <- "binary" 
       if(ratio.of.means.instead.of.difference.in.means){
         statistic <- "ratio.of.means"
         }else{
         statistic <- "difference.in.means"
         }
       }

    if(is.element(type.1,c("ordinal","dirac.and.continuous")) & 
       is.element(type.2,c("ordinal","dirac.and.continuous")) & is.null(statistic)){
       statistic <- "sample.correlation.coefficient"
       }

    if(is.element(type.1,c("numerical","dirac.and.continuous")) & 
       is.element(type.2,c("numerical","dirac.and.continuous")) & is.null(statistic)){
       if(sample.correlation.coefficient.instead.of.Spearman){
          statistic <- "sample.correlation.coefficient"
	        }else{
          statistic <- "Spearman.correlation.coefficient"
	        }
       }

    if(is.element(type.1,"categorical") & 
       is.element(type.2,c("numerical","dirac.and.continuous","ordinal")) & is.null(statistic)){
       variables.by.stratum[,1:2] <- variables.by.stratum[,2:1]
       type.1 <- type.2; type.2 <- "binary"
       statistic <- "mean.absolute.deviation.from.overall.mean"
       }

    if(is.element(type.2,"categorical") & 
       is.element(type.1,c("numerical","dirac.and.continuous","ordinal")) & is.null(statistic)){
       statistic <- "mean.absolute.deviation.from.overall.mean"
       }

    if(statistic=="odds.ratio"){
	    sample.sizes <- aggregate(y~stratum,data=variables.by.stratum,length)
	    weights <- sample.sizes[,2]/sum(sample.sizes[,2])
	    odds.ratios <- sapply(sort(unique(variables.by.stratum$stratum)),
	                          odds.ratio.per.stratum,variables.by.stratum)
	    weighted.odds.ratio <- sum(odds.ratios*weights)
	    value.of.statistic <- weighted.odds.ratio
	    }

    if(statistic=="Cramer.V"){
	    sample.sizes <- aggregate(y~stratum,data=variables.by.stratum,length)
	    weights <- sample.sizes[,2]/sum(sample.sizes[,2])
	    Cramer.Vs <- sapply(sort(unique(variables.by.stratum$stratum)),
	                        Cramer.V.per.stratum,variables.by.stratum)
	    weighted.Cramer.V <- sum(Cramer.Vs*weights)
	    value.of.statistic <- weighted.Cramer.V
	    }

    if(statistic=="mean.absolute.difference.in.proportions"){
	    sample.sizes <- aggregate(y~stratum,data=variables.by.stratum,length)
	    weights <- sample.sizes[,2]/sum(sample.sizes[,2])
	    all.categories <- sort(unique(variables.by.stratum$y))
	    variables.by.stratum <- transform(variables.by.stratum,
                                        y=factor(y,levels=all.categories,labels=all.categories))
	    mean.absolute.differences <- sapply(sort(unique(variables.by.stratum$stratum)),
                                          mean.absolute.difference.in.proportions.per.stratum,
                                          variables.by.stratum)
	    weighted.mean.absolute.difference <- sum(mean.absolute.differences*weights)
	    value.of.statistic <- weighted.mean.absolute.difference
	    }

    if(statistic=="sample.correlation.coefficient"){
      sample.sizes <- aggregate(y~stratum,data=variables.by.stratum,length)
      weights <- sample.sizes[,2]/sum(sample.sizes[,2])
      sample.correlations <- sapply(sort(unique(variables.by.stratum$stratum)),
                                    correlation.per.stratum,
                                    variables.by.stratum)
      weighted.sample.correlation <- sum(sample.correlations*weights)
      value.of.statistic <- weighted.sample.correlation
      }

    if(statistic=="Spearman.correlation.coefficient"){
      sample.sizes <- aggregate(y~stratum,data=variables.by.stratum,length)
      weights <- sample.sizes[,2]/sum(sample.sizes[,2])
      Spearman.correlations <- sapply(sort(unique(variables.by.stratum$stratum)),
                                      Spearman.per.stratum,
                                      variables.by.stratum)
      weighted.Spearman.correlation <- sum(Spearman.correlations*weights)
      value.of.statistic <- weighted.Spearman.correlation
      }

    if(statistic=="difference.in.means"){
      sample.sizes <- aggregate(y~stratum,data=variables.by.stratum,length)
      weights <- sample.sizes[,2]/sum(sample.sizes[,2])
      differences.in.means <- sapply(sort(unique(variables.by.stratum$stratum)),
                                          difference.in.means.per.stratum,
                                          variables.by.stratum)
      weighted.difference.in.means <- sum(differences.in.means*weights)
      value.of.statistic <- weighted.difference.in.means
      }

    if(statistic=="ratio.of.means"){
      sample.sizes <- aggregate(y~stratum,data=variables.by.stratum,length)
      weights <- sample.sizes[,2]/sum(sample.sizes[,2])
      ratios.of.means <- sapply(sort(unique(variables.by.stratum$stratum)),
                                ratio.of.means.per.stratum,
                                variables.by.stratum)
      weighted.ratio.of.means <- ifelse(median.of.ratios.instead.of.mean.of.ratios,
                                        median(ratios.of.means,na.rm=T),sum(ratios.of.means*weights))
      value.of.statistic <- weighted.ratio.of.means
      }
                
    if(statistic=="mean.absolute.deviation.from.overall.mean"){
	    sample.sizes <- aggregate(y~stratum,data=variables.by.stratum,length)
	    weights <- sample.sizes[,2]/sum(sample.sizes[,2])
	    mean.absolute.deviations <- sapply(sort(unique(variables.by.stratum$stratum)),
                                         mean.absolute.deviation.from.overall.mean,
                                         variables.by.stratum)
	    weighted.mean.absolute.deviation <- sum(mean.absolute.deviations*weights)
	    value.of.statistic <- weighted.mean.absolute.deviation
	    }

    }
  
  if(is.na(value.of.statistic)){
    print(paste("Did not calculate statistic on ",
          paste(names(data.for.calculating)[1:2],collapse=", "),"!",sep=""))
    }
 
# NB: The output may not return the original types but rather those assumed for the calculation 
  return(c(names(data.for.calculating)[1:2],type.1,type.2,value.of.statistic,statistic))
  }
#
############################################################################################################
# statistics.over.strata
############################################################################################################
Spearman.per.stratum <- function(s,variables.by.stratum){
  return(cor(x=subset(variables.by.stratum,stratum==s)[,1],
             y=subset(variables.by.stratum,stratum==s)[,2],method="spearman"))
}
correlation.per.stratum <- function(s,variables.by.stratum){
  return(cor(x=subset(variables.by.stratum,stratum==s)[,1],
             y=subset(variables.by.stratum,stratum==s)[,2]))
}
odds.ratio.per.stratum <- function(s,variables.by.stratum){
  Fisher.test <- fisher.test(table(subset(variables.by.stratum,stratum==s)[,-3]))
  return(as.numeric(Fisher.test$estimate))
}
Cramer.V.per.stratum <- function(s,variables.by.stratum){
  aux.variables.by.stratum <- subset(variables.by.stratum,stratum==s)[,-3]
  table(aux.variables.by.stratum)
  if(is.factor(aux.variables.by.stratum$x)){
    aux.variables.by.stratum$x <- as.character(aux.variables.by.stratum$x)}
  if(is.factor(aux.variables.by.stratum$y)){
    aux.variables.by.stratum$y <- as.character(aux.variables.by.stratum$y)}
  aux.table <- table(aux.variables.by.stratum)
  if(min(dim(aux.table))>1){
    Chi.square.test <- chisq.test(aux.table,simulate.p.value=TRUE,B=10)
    Cramer.V <- sqrt(as.numeric(Chi.square.test$statistic)/(sum(aux.table)*min(dim(aux.table)-1)))
  }else{
    Cramer.V <- NA
  }
  return(Cramer.V)
}
difference.in.means.per.stratum <- function(s,variables.by.stratum){
  mean.of.y.by.x <- aggregate(y~x,data=subset(variables.by.stratum,stratum==s)[,-3],mean)
  difference.between.means <- (mean.of.y.by.x$y[2]-mean.of.y.by.x$y[1])
  return(difference.between.means)
}
ratio.of.means.per.stratum <- function(s,variables.by.stratum){
  mean.of.y.by.x <- aggregate(y~x,data=subset(variables.by.stratum,stratum==s)[,-3],mean)
  ratio.of.means <- (mean.of.y.by.x$y[2]/mean.of.y.by.x$y[1])
  return(ratio.of.means)
}
mean.absolute.difference.in.proportions.per.stratum <- function(s,variables.by.stratum){
  contingency.table <- table(subset(variables.by.stratum,stratum==s)[,-3])
  if(dim(contingency.table)[1]>dim(contingency.table)[2]){
    contingency.table <- t(contingency.table)
  }
  row.sums <- pmax(rowSums(contingency.table),1)
  relative.frequencies <- contingency.table/row.sums
  differences.between.proportions <- abs(relative.frequencies[1,]-relative.frequencies[2,])
  return(mean(differences.between.proportions))
}
mean.absolute.deviation.from.overall.mean <- function(s,variables.by.stratum){
  mean.of.y.by.x <- aggregate(y~x,data=subset(variables.by.stratum,stratum==s)[,-3],mean)
  overall.mean <- mean(subset(variables.by.stratum,stratum==s)$y)
  mean.absolute.deviation <- mean(abs(mean.of.y.by.x$y-overall.mean))
  return(mean.absolute.deviation)
}
#
statistics.over.strata <- function(data.for.calculating,TYPES,odds.ratio.instead.of.Cramer.V,
                                   sample.correlation.coefficient.instead.of.Spearman,
                                   ratio.of.means.instead.of.difference.in.means,
                                   median.of.ratios.instead.of.mean.of.ratios,
                                   mean.absolute.difference.in.proportions.instead.of.Cramer.V,
                                   switch.to.binary){
  # data.for.calculating <- example # data.set.i.j # data.for.testing.i
  # TYPES <- TYPES.i
  # odds.ratio.instead.of.Cramer.V <- F
  # sample.correlation.coefficient.instead.of.Spearman <- T
  # ratio.of.means.instead.of.difference.in.means <- F
  # median.of.ratios.instead.of.mean.of.ratios <- F
  # mean.absolute.difference.in.proportions.instead.of.Cramer.V <- T
  # switch.to.binary <- F
  
  variables.by.stratum <- data.for.calculating
  variables.by.stratum$stratum <- as.character(variables.by.stratum$stratum)
  names(variables.by.stratum)[1:2] <- c("y","x")
  
  checks.by.stratum <- t(sapply(variables.by.stratum$stratum,check.strata,variables.by.stratum))
  good.strata <- unique(variables.by.stratum$stratum[checks.by.stratum>1])
  
  statistic <- NULL
  value.of.statistic <- NA
  
  if(length(good.strata)>1){
    
    variables.by.stratum <- subset(variables.by.stratum,is.element(stratum,good.strata))
    rownames(variables.by.stratum) <- NULL
    variables.by.stratum$stratum <- as.factor(variables.by.stratum$stratum)
    
    type.1 <- TYPES[1]; type.2 <- TYPES[2]
    
    if(switch.to.binary){    
      if(length(unique(variables.by.stratum[,1]))==2){type.1 <- "binary"}
      if(length(unique(variables.by.stratum[,2]))==2){type.2 <- "binary"}
      if((type.1=="categorical") & (length(unique(variables.by.stratum[,1]))==2)){type.1 <- "binary"}
      if((type.2=="categorical") & (length(unique(variables.by.stratum[,2]))==2)){type.2 <- "binary"}
    }
    
    if((type.1=="binary") & (type.2=="binary")){
      if(odds.ratio.instead.of.Cramer.V){
        statistic <- "odds.ratio"}else{statistic <- "Cramer.V"
        }
    }
    
    if((type.2=="binary") & (type.1=="categorical")){
      if(mean.absolute.difference.in.proportions.instead.of.Cramer.V){
        statistic <- "mean.absolute.difference.in.proportions"
      }else{
        statistic <- "Cramer.V"
      }
    }
    
    if((type.1=="binary") & (type.2=="categorical" & is.null(statistic))){
      variables.by.stratum[,1:2] <- variables.by.stratum[,2:1]
      type.2 <- "binary"; type.1 <- "categorical"
      statistic <- "mean.absolute.difference.in.proportions"
    }
    
    if((type.1=="categorical") & (type.2=="categorical") & is.null(statistic)){
      statistic <- "Cramer.V"
    }
    
    if(is.element(type.1,c("numerical","dirac.and.continuous","ordinal","continuous")) & 
       (type.2=="binary") & is.null(statistic)){
      if(ratio.of.means.instead.of.difference.in.means){
        statistic <- "ratio.of.means"
      }else{
        statistic <- "difference.in.means"
      }
    }
    
    if(is.element(type.2,c("numerical","dirac.and.continuous","ordinal","continuous")) & 
       (type.1=="binary") & is.null(statistic)){
      variables.by.stratum[,1:2] <- variables.by.stratum[,2:1]
      type.1 <- type.2; type.2 <- "binary" 
      if(ratio.of.means.instead.of.difference.in.means){
        statistic <- "ratio.of.means"
      }else{
        statistic <- "difference.in.means"
      }
    }
    
    if(is.element(type.1,c("ordinal","dirac.and.continuous","continuous")) & 
       is.element(type.2,c("ordinal","dirac.and.continuous","continuous")) & is.null(statistic)){
      statistic <- "sample.correlation.coefficient"
    }
    
    if(is.element(type.1,c("numerical","dirac.and.continuous","continuous")) & 
       is.element(type.2,c("numerical","dirac.and.continuous","continuous")) & is.null(statistic)){
      if(sample.correlation.coefficient.instead.of.Spearman){
        statistic <- "sample.correlation.coefficient"
      }else{
        statistic <- "Spearman.correlation.coefficient"
      }
    }
    
    if(is.element(type.1,"categorical") & 
       is.element(type.2,c("numerical","dirac.and.continuous","ordinal","continuous")) & is.null(statistic)){
      variables.by.stratum[,1:2] <- variables.by.stratum[,2:1]
      type.1 <- type.2; type.2 <- "binary"
      statistic <- "mean.absolute.deviation.from.overall.mean"
    }
    
    if(is.element(type.2,"categorical") & 
       is.element(type.1,c("numerical","dirac.and.continuous","ordinal","continuous")) & is.null(statistic)){
      statistic <- "mean.absolute.deviation.from.overall.mean"
    }
    
    if(statistic=="odds.ratio"){
      sample.sizes <- aggregate(y~stratum,data=variables.by.stratum,length)
      weights <- sample.sizes[,2]/sum(sample.sizes[,2])
      odds.ratios <- sapply(sort(unique(variables.by.stratum$stratum)),
                            odds.ratio.per.stratum,variables.by.stratum)
      weighted.odds.ratio <- sum(odds.ratios*weights)
      value.of.statistic <- weighted.odds.ratio
    }
    
    if(statistic=="Cramer.V"){
      # print("Cramer.V")
      sample.sizes <- aggregate(y~stratum,data=variables.by.stratum,length)
      weights <- sample.sizes[,2]/sum(sample.sizes[,2])
      Cramer.Vs <- sapply(sort(unique(variables.by.stratum$stratum)),
                          Cramer.V.per.stratum,variables.by.stratum)
      # print(Cramer.Vs)
      weighted.Cramer.V <- sum(Cramer.Vs*weights)
      value.of.statistic <- weighted.Cramer.V
    }
    
    if(statistic=="mean.absolute.difference.in.proportions"){
      # print("mean.absolute.difference.in.proportions")
      sample.sizes <- aggregate(y~stratum,data=variables.by.stratum,length)
      sample.sizes <- sample.sizes[order(sample.sizes$stratum),]
      weights <- sample.sizes[,2]/sum(sample.sizes[,2])
      all.categories <- sort(unique(variables.by.stratum$y))
      # variables.by.stratum <- transform(variables.by.stratum,
      #                                   y=factor(y,levels=all.categories,labels=all.categories))
      mean.absolute.differences <- sapply(sort(unique(as.character(variables.by.stratum$stratum))),
                                          mean.absolute.difference.in.proportions.per.stratum,
                                          variables.by.stratum)
      # print(mean.absolute.differences)
      weighted.mean.absolute.difference <- sum(mean.absolute.differences*weights)
      value.of.statistic <- weighted.mean.absolute.difference
    }
    
    if(statistic=="sample.correlation.coefficient"){
      sample.sizes <- aggregate(y~stratum,data=variables.by.stratum,length)
      weights <- sample.sizes[,2]/sum(sample.sizes[,2])
      sample.correlations <- sapply(sort(unique(variables.by.stratum$stratum)),
                                    correlation.per.stratum,
                                    variables.by.stratum)
      weighted.sample.correlation <- sum(sample.correlations*weights)
      value.of.statistic <- weighted.sample.correlation
    }
    
    if(statistic=="Spearman.correlation.coefficient"){
      sample.sizes <- aggregate(y~stratum,data=variables.by.stratum,length)
      weights <- sample.sizes[,2]/sum(sample.sizes[,2])
      Spearman.correlations <- sapply(sort(unique(variables.by.stratum$stratum)),
                                      Spearman.per.stratum,
                                      variables.by.stratum)
      weighted.Spearman.correlation <- sum(Spearman.correlations*weights)
      value.of.statistic <- weighted.Spearman.correlation
    }
    
    if(statistic=="difference.in.means"){
      sample.sizes <- aggregate(y~stratum,data=variables.by.stratum,length)
      weights <- sample.sizes[,2]/sum(sample.sizes[,2])
      differences.in.means <- sapply(sort(unique(variables.by.stratum$stratum)),
                                     difference.in.means.per.stratum,
                                     variables.by.stratum)
      weighted.difference.in.means <- sum(differences.in.means*weights)
      value.of.statistic <- weighted.difference.in.means
    }
    
    if(statistic=="ratio.of.means"){
      sample.sizes <- aggregate(y~stratum,data=variables.by.stratum,length)
      weights <- sample.sizes[,2]/sum(sample.sizes[,2])
      ratios.of.means <- sapply(sort(unique(variables.by.stratum$stratum)),
                                ratio.of.means.per.stratum,
                                variables.by.stratum)
      weighted.ratio.of.means <- ifelse(median.of.ratios.instead.of.mean.of.ratios,
                                        median(ratios.of.means,na.rm=T),sum(ratios.of.means*weights))
      value.of.statistic <- weighted.ratio.of.means
    }
    
    if(statistic=="mean.absolute.deviation.from.overall.mean"){
      sample.sizes <- aggregate(y~stratum,data=variables.by.stratum,length)
      weights <- sample.sizes[,2]/sum(sample.sizes[,2])
      mean.absolute.deviations <- sapply(sort(unique(variables.by.stratum$stratum)),
                                         mean.absolute.deviation.from.overall.mean,
                                         variables.by.stratum)
      weighted.mean.absolute.deviation <- sum(mean.absolute.deviations*weights)
      value.of.statistic <- weighted.mean.absolute.deviation
    }
    
  }
  
  if(is.na(value.of.statistic)){
    print(paste("Did not calculate statistic on ",
                paste(names(data.for.calculating)[1:2],collapse=", "),"!",sep=""))
  }
  
  # NB: The output may not return the original types but rather those assumed for the calculation 
  return(c(names(data.for.calculating)[1:2],type.1,type.2,value.of.statistic,statistic))
}
#
############################################################################################################






































































